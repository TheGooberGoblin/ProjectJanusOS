# Janus 5.0 LaTeX Project

This archive contains:
- `main.tex`: Compiles the master mathematical specification.
- `Janus_5.0_Mathematical_Standard.tex`: The full formal document.
- `cover_letter.tex`: A short cover letter in LaTeX format.
- `README.txt`: Basic overview.

Upload this ZIP directly to Overleaf. Compile `main.tex` to get the specification, or `cover_letter.tex` to produce the letter.
